# Changelog

## [0.30.4-dev](https://github.com/sillen102/simba/compare/telemetry/v0.30.3-dev...telemetry/v0.30.4-dev) (2026-03-01)


### Features

* abandon websockets with Centrifugal, for now ([187e7d4](https://github.com/sillen102/simba/commit/187e7d40145d351745dbe50256276e3768816e9b))

## [0.30.3-dev](https://github.com/sillen102/simba/compare/telemetry/v0.30.2-dev...telemetry/v0.30.3-dev) (2026-03-01)


* **telemetry:** Synchronize simba-monorepo versions

## [0.30.2-dev](https://github.com/sillen102/simba/compare/telemetry/v0.30.1-dev...telemetry/v0.30.2-dev) (2026-02-11)


### Bug Fixes

* add functions to work with contexts ([36b64cc](https://github.com/sillen102/simba/commit/36b64cc74f088e97126da151bb292b78e800d54b))

## [0.30.1-dev](https://github.com/sillen102/simba/compare/telemetry/v0.30.0-dev...telemetry/v0.30.1-dev) (2026-02-08)


* **telemetry:** Synchronize simba-monorepo versions

## [0.30.1-dev](https://github.com/sillen102/simba/compare/telemetry/v0.30.0-dev...telemetry/v0.30.1-dev) (2026-02-08)


* **telemetry:** Synchronize simba-monorepo versions

## [0.30.1-dev](https://github.com/sillen102/simba/compare/telemetry-v0.30.0-dev...telemetry-v0.30.1-dev) (2026-02-08)


* **telemetry:** Synchronize simba-monorepo versions

## [0.30.1-dev](https://github.com/sillen102/simba/compare/telemetry-v0.30.0-dev...telemetry-v0.30.1-dev) (2026-02-08)


* **telemetry:** Synchronize simba-monorepo versions

## [0.30.1-dev](https://github.com/sillen102/simba/compare/telemetry-v0.30.0-dev...telemetry-v0.30.1-dev) (2026-02-08)


* **telemetry:** Synchronize simba-monorepo versions
